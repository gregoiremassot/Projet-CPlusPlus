//
// Gregoire Massot
//

#ifndef PROJET_CPP_ETUDIANTLICENCE_H
#define PROJET_CPP_ETUDIANTLICENCE_H
#include "Etudiant.h"


class EtudiantLicence : public Etudiant
{
public:
    EtudiantLicence(string nom_fichier);
};


#endif //PROJET_CPP_ETUDIANTLICENCE_H
