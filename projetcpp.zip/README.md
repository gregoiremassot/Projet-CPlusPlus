# projetcpp

Grégoire MASSOT - David Anthony SELLEM
2018

Pour compiler sous linux :
1) Se placer dans le dossier
2) Compiler le programme : g++ ./cpp/*.cpp -o bin/projetcpp -std=c++11
3) Aller dans bin : cd bin 
4) Lancer le programme ./projetcpp
